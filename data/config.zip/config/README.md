The config.zip file will be downloadable from your website,
name your specific file like this, or change the download file name
in the index.html source code.